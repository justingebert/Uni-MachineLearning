package de.htw.ml;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jblas.FloatMatrix;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

public class Ue06_Vorlage_Java {

	// TODO change the names of the axis
	public static final String title = "Line Chart";
	public static final String xAxisLabel = "Car Index";
	public static final String yAxisLabel = "mpg";
	
	public static void main(String[] args) throws IOException {
		FloatMatrix cars = FloatMatrix.loadCSVFile("cars_jblas.csv");
		
		// TODO implement your own code here
		FloatMatrix column6 = cars.getColumn(6);
		float[] yVals = column6.toArray();
		
		// plot the RMSE values
		FXApplication.plot(yVals, "Linear Regression");
		Application.launch(FXApplication.class);
	}

	
	

	// ---------------------------------------------------------------------------------
	// --------------- All changes from here on are at your own risk -------------------
	// ---------------------------------------------------------------------------------
	
	
	/**
	 * We need a separate class in order to trick Java 11 to start our JavaFX application without any module-path settings.
	 * https://stackoverflow.com/questions/52144931/how-to-add-javafx-runtime-to-eclipse-in-java-11/55300492#55300492
	 * 
	 * @author Nico Hezel
	 *
	 */
	public static class FXApplication extends Application {
	
		/**
		 * equivalent to linspace
		 * 
		 * @param lower
		 * @param upper
		 * @param num
		 * @return
		 */
		private static FloatMatrix linspace(float lower, float upper, int num) {
	        float[] data = new float[num];
	        float step = Math.abs(lower-upper) / (num-1);
	        for (int i = 0; i < num; i++)
	            data[i] = lower + (step * i);
	        data[0] = lower;
	        data[data.length-1] = upper;
	        return new FloatMatrix(data);
	    }
		
		// y-axis values of the plot 
		private static List<float[]> dataYList = new ArrayList<>();
		private static List<String> dataYNameList = new ArrayList<>();
		
		/**
		 * Remembers the values and the name of the data
		 * 
		 * @param yValues
		 * @param name
		 */
		public static void plot(float[] yValues, String name) {
			dataYList.add(yValues);
			dataYNameList.add(name);
		}
		
		/**
		 * draw the UI
		 */
		@Override 
		public void start(Stage stage) {
	
			stage.setTitle(title);
			
			final NumberAxis xAxis = new NumberAxis();
			xAxis.setLabel(xAxisLabel);
	        final NumberAxis yAxis = new NumberAxis();
	        yAxis.setLabel(yAxisLabel);
	        
			final LineChart<Number, Number> sc = new LineChart<>(xAxis, yAxis);
			sc.setAnimated(false);
			sc.setCreateSymbols(true);
	
			for (int s = 0; s < dataYList.size(); s++) {				
				XYChart.Series<Number, Number> series = new XYChart.Series<>();
				series.setName(dataYNameList.get(s));
				
				float[] dataY = dataYList.get(s);
				for (int i = 0; i < dataY.length; i++)
					series.getData().add(new XYChart.Data<Number, Number>(i, dataY[i]));
				sc.getData().add(series);
			}	
	
			Scene scene = new Scene(sc, 500, 400);
			stage.setScene(scene);
			stage.show();
	    }
	}
}
